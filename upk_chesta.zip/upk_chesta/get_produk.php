<?php
include "koneksi.php";

// Query untuk mengambil data produk
$sql_produk = "SELECT id_produk, nama_produk FROM produk";
$result_produk = $koneksi->query($sql_produk);

// Buat dropdown option berdasarkan data produk yang diambil
$options = "";
if ($result_produk->num_rows > 0) {
    while($row_produk = $result_produk->fetch_assoc()) {
        $options .= '<option value="' . $row_produk['id_produk'] . '">' . $row_produk['nama_produk'] . '</option>';
    }
}

echo $options;

$koneksi->close();
?>