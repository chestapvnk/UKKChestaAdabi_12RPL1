<?php
session_start();
if (!isset($_SESSION["id_kasir"])) {
  header("location: login.php");
  exit(); // Penting untuk menghentikan eksekusi skrip setelah mengarahkan pengguna
} else {// Penting untuk menghentikan eksekusi skrip setelah mengarahkan pengguna

  // Konten halaman dashboard di sini
  // ...
  
?>
<!DOCTYPE html>
<html>

<head>
    <title>Edit Produk</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="author" content="">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Jost:wght@300;400;500&family=Lato:wght@300;400;700&display=swap"
        rel="stylesheet">
    <style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 0;
        background: linear-gradient(to right, #667db6, #0082c8, #0082c8, #667db6);
        color: #333;
    }

    .container {
        max-width: 500px;
        margin: 50px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    h2 {
        text-align: center;
        color: #000000;
    }

    .form-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-left: 10px;
    }

   
    /* label {
        margin-bottom: 10px;
        font-weight: bold;
    } */

    input[type="text"] {
        padding: 10px;
        width: 455px;
        margin-right:40px;
        margin-bottom: 20px;
        border: none;
        border-radius: 5px;
        background-color: #f2f2f2;
        box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
    }

    input[type="submit"] {
        padding: 10px 20px;
        background-color: #215e82;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    input[type="submit"]:hover {
        background-color: #215e82;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    table th,
    table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    table th {
        background-color: #f2f2f2;
    }

    table tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    form {
        margin-bottom: 20px;
    }

    button[name="search"] {

        padding: 10px 20px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;

    }

    button[name="search"]:hover {
        background-color: #45a049;
    }

    /* Style untuk tombol "Tampilkan Semua" */
    button[type="button"] {
        padding: 10px 20px;
        background-color: #215e82;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    button[type="button"]:hover {
        background-color: #1a4761;
    }
    .form-actions {
    display: flex;
    justify-content: space-between;
}

.form-actions button {
    flex: 1;
    margin-left: 6px; /* Atur jarak antara tombol */
}
    </style>


    <!-- script
    ================================================== -->
    <script src="js/modernizr.js"></script>



</head>

<body data-bs-spy="scroll" data-bs-target="#navbar" data-bs-root-margin="0px 0px -40%" data-bs-smooth-scroll="true"
    tabindex="0">

    <!-- navbar -->
    <header id="header" class="site-header header-scrolled position-relative text-black bg-light">
        <nav id="header-nav" class="navbar navbar-expand-lg px-3 mb-3">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.html">
                    <img src="images/main-logo.png" class="logo">
                </a>
                <button class="navbar-toggler d-flex d-lg-none order-3 p-2" type="button" data-bs-toggle="offcanvas"
                    data-bs-target="#bdNavbar" aria-controls="bdNavbar" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <svg class="navbar-icon">
                        <use xlink:href="#navbar-icon"></use>
                    </svg>
                </button>
                <div class="offcanvas offcanvas-end" tabindex="-1" id="bdNavbar"
                    aria-labelledby="bdNavbarOffcanvasLabel">
                    <div class="offcanvas-header px-4 pb-0">
                        <a class="navbar-brand" href="index.html">
                            <img src="images/main-logo.png" class="logo">
                        </a>
                        <button type="button" class="btn-close btn-close-black" data-bs-dismiss="offcanvas"
                            aria-label="Close" data-bs-target="#bdNavbar"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul id="navbar"
                            class="navbar-nav text-uppercase justify-content-end align-items-center flex-grow-1 pe-3">
                            <li class="nav-item">
                                <a class="nav-link me-4" href="#billboard">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link me-4" href="#company-services">Kasir</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link me-4 dropdown-toggle link-dark" data-bs-toggle="dropdown" href="#"
                                    role="button" aria-expanded="false">Produk</a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a class="nav-link me-4 ctive " href="data_produk.php">Data Produk</a>
                                    </li>
                                    <li>
                                        <a class="nav-link me-4 ctive " href="tambah_produk.php">Tambah Produk</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link me-4 dropdown-toggle link-dark" data-bs-toggle="dropdown" href="#"
                                    role="button" aria-expanded="false">Penjualan</a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="about.html" class="dropdown-item">Penjualan</a>
                                    </li>
                                    <li>
                                        <a href="blog.html" class="dropdown-item">Detail Penjualan</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <div class="user-items ps-5">
                                    <ul class="d-flex justify-content-end list-unstyled">

                                        <li class="nav-item">
                                            <a class="nav-link" href="logout.php">Logout</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <!-- konten -->

    <div class="container">
        <h2>Edit Produk</h2>
        <?php
        include "koneksi.php";

        // Pastikan ada parameter ProdukID yang dikirimkan melalui URL
        if(isset($_GET['id'])) {
            $id_produk = $_GET['id'];

            // Query untuk mendapatkan data produk berdasarkan ProdukID
            $sql = "SELECT * FROM produk WHERE id_produk = '$id_produk'";
            $result = $koneksi->query($sql);

            if ($result->num_rows > 0) {
                // Tampilkan form edit dengan nilai awal berdasarkan data produk
                $row = $result->fetch_assoc();
        ?>
                <form action="" method="POST">
                    <input type="hidden" name="id_produk" value="<?php echo $row['id_produk']; ?>">
                    <label for="nama_produk">Nama Produk:</label><br>
                    <input type="text" id="nama_produk" name="nama_produk" value="<?php echo $row['nama_produk']; ?>"><br>
                    
                    <label for="harga">Harga:</label><br>
                    <input type="text" id="harga" name="harga" value="<?php echo $row['harga']; ?>"><br>
                    
                    <label for="Stok">Stok:</label><br>
                    <input type="text" id="stok" name="stok" value="<?php echo $row['stok']; ?>"><br><br>
                    
                    <div class="form-actions">
                    <input type="submit" value="update">
                    <button type="button" onclick="cancel()">Cancel</button>
                    </div>
                </form>
                <script>
                    function cancel() {
                    window.location.href = "data_produk.php";
                    }
                </script>
        <?php
            } else {
                echo "Data produk tidak ditemukan.";
            }
        } else {
            echo "ProdukID tidak ditemukan.";
        }

        $koneksi->close();
        ?>
    </div>
<?php

    include "koneksi.php";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Tangkap data dari formulir
        $id_produk = $_POST['id_produk'];
        $nama_produk = $_POST['nama_produk'];
        $harga = $_POST['harga'];
        $stok = $_POST['stok'];
    
        // Query untuk melakukan update data produk
        $sql = "UPDATE produk SET nama_produk='$nama_produk', harga='$harga', stok='$stok' WHERE id_produk='$id_produk'";
    
        if ($koneksi->query($sql) === TRUE) {
            // Jika update berhasil, redirect ke halaman produk.php
            header("Location: data_produk.php");
            exit;
        } else {
            // Jika terjadi kesalahan, tampilkan pesan error
            echo "Error: " . $sql . "<br>" . $koneksi->error;
        }
    }
    
    // Tutup koneksi
    $koneksi->close();
?>
<div class="swiper-pagination position-absolute text-center"></div>
    </section>
    <script src="js/jquery-1.11.0.min.js">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="js/plugins.js"></script>
    <script type="text/javascript" src="js/script.js"></script>
</body>

</html>
<?php
}
?>