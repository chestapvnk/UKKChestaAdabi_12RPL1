<?php
session_start();
if (!isset($_SESSION["id_kasir"])) {
  header("location: login.php");
  exit(); // Penting untuk menghentikan eksekusi skrip setelah mengarahkan pengguna
} else {// Penting untuk menghentikan eksekusi skrip setelah mengarahkan pengguna

  // Konten halaman dashboard di sini
  // ...
  
?>
<!DOCTYPE html>
<html>

<head>
    <title>Data Penjualan</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="author" content="">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Jost:wght@300;400;500&family=Lato:wght@300;400;700&display=swap"
        rel="stylesheet">
    <style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 0;
        background: linear-gradient(to right, #667db6, #0082c8, #0082c8, #667db6);
        color: #333;
    }

    .container {
        max-width: 500px;
        margin: 50px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    h2 {
        text-align: center;
        color: #000000;
    }

    .form-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-left: 10px;
    }

   
    /* label {
        margin-bottom: 10px;
        font-weight: bold;
    } */

    input[type="text"] {
        padding: 10px;
        width: 300px;
        margin-right:5px;
        margin-bottom: 20px;
        border: none;
        border-radius: 5px;
        background-color: #f2f2f2;
        box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
    }

    input[type="submit"] {
        padding: 10px 20px;
        background-color: #215e82;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    input[type="submit"]:hover {
        background-color: #215e82;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    table th,
    table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    table th {
        background-color: #f2f2f2;
    }

    table tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    form {
        margin-bottom: 20px;
    }

    button[name="search"] {

        padding: 10px 20px;
        margin: ;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;

    }

    button[name="search"]:hover {
        background-color: #45a049;
    }

    /* Style untuk tombol "Tampilkan Semua" */
    button[type="button"] {
        padding: 10px 20px;
        background-color: #215e82;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    button[type="button"]:hover {
        background-color: #1a4761;
    }
    .container {
    max-width: 1000px; /* Anda dapat menyesuaikan lebar maksimum sesuai kebutuhan Anda */
    margin: 70px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 20px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    }

    table {
    width: 100%; /* Menyesuaikan tabel agar mengambil lebar maksimum dari kontainer */
    }

    /* Menyesuaikan lebar setiap sel dalam tabel */
    th, td {
    width: 0%; /* Anda dapat menyesuaikan lebar setiap sel sesuai kebutuhan Anda */
    }
    </style>


    <!-- script
    ================================================== -->
    <script src="js/modernizr.js"></script>



</head>

<body data-bs-spy="scroll" data-bs-target="#navbar" data-bs-root-margin="0px 0px -40%" data-bs-smooth-scroll="true"
    tabindex="0">

    <!-- navbar -->
    <header id="header" class="site-header header-scrolled position-relative text-black bg-light">
        <nav id="header-nav" class="navbar navbar-expand-lg px-3 mb-3">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.html">
                    <img src="images/main-logo.png" class="logo">
                </a>
                <button class="navbar-toggler d-flex d-lg-none order-3 p-2" type="button" data-bs-toggle="offcanvas"
                    data-bs-target="#bdNavbar" aria-controls="bdNavbar" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <svg class="navbar-icon">
                        <use xlink:href="#navbar-icon"></use>
                    </svg>
                </button>
                <div class="offcanvas offcanvas-end" tabindex="-1" id="bdNavbar"
                    aria-labelledby="bdNavbarOffcanvasLabel">
                    <div class="offcanvas-header px-4 pb-0">
                        <a class="navbar-brand" href="index.html">
                            <img src="images/main-logo.png" class="logo">
                        </a>
                        <button type="button" class="btn-close btn-close-black" data-bs-dismiss="offcanvas"
                            aria-label="Close" data-bs-target="#bdNavbar"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul id="navbar"
                            class="navbar-nav text-uppercase justify-content-end align-items-center flex-grow-1 pe-3">
                            <li class="nav-item">
                                <a class="nav-link me-4" href="#billboard">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link me-4" href="insert_penjualan.php">Kasir</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link me-4 dropdown-toggle link-dark" data-bs-toggle="dropdown" href="#"
                                    role="button" aria-expanded="false">Produk</a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a class="nav-link me-4 ctive " href="data_produk.php">Data Produk</a>
                                    </li>
                                    <li>
                                        <a class="nav-link me-4 ctive " href="tambah_produk.php">Tambah Produk</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link me-4 dropdown-toggle link-dark" data-bs-toggle="dropdown" href="#"
                                    role="button" aria-expanded="false">Penjualan</a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="data_penjualan.php" class="dropdown-item">Penjualan</a>
                                    </li>
                                    <li>
                                        <a href="data_detailpenjualan" class="dropdown-item">Detail Penjualan</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <div class="user-items ps-5">
                                    <ul class="d-flex justify-content-end list-unstyled">

                                        <li class="nav-item active">
                                            <a class="nav-link" href="logout.php">Logout</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <!-- konten -->
    <div class="container">
        <h2>Detail Penjualan</h2>
        <form action="" method="GET">
        <input type="text" name="search_query"
                placeholder="Cari berdasarkan ProdukID, NamaProduk, Harga, atau Stok">
                <button type="submit" name="search">Search</button>
        </form>
        </form>
        <table>
            <thead>
                <tr>
                    <th>PenjualanID</th>
                    <th>DetailID</th>
                    <th>ProdukID</th>
                    <th>JumlahProduk</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Include database connection
                include "koneksi.php";

                // Initialize the query
                $sql = "SELECT id_penjualan, id_detail, id_produk, jmlh_produk, sub_total FROM detail_penjualan";

                // Check if search query is set
                if(isset($_GET['search'])) {
                    $search_query = $_GET['search_query'];
                    // Add WHERE clause for search
                    $sql .= " WHERE id_penjualan LIKE '%$search_query%' OR id_detail LIKE '%$search_query%' OR id_produk LIKE '%$search_query%' OR jmlh_produk LIKE '%$search_query%' OR sub_total LIKE '%$search_query%'";
                }

                // Attempt to execute the query
                $result = $koneksi->query($sql);

                // Check if the query execution was successful
                if ($result) {
                    // Check if there are any rows returned
                    if ($result->num_rows > 0) {
                        // Output data for each row
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>".$row["id_penjualan"]."</td>";
                            echo "<td>".$row["id_detail"]."</td>";
                            echo "<td>".$row["id_produk"]."</td>";
                            echo "<td>".$row["jmlh_produk"]."</td>";
                            echo "<td>".$row["sub_total"]."</td>";
                            echo "<td>";
                            echo "<a href='edit_detail_penjualan.php?id=".$row["id_detail"]."'>Edit</a> | ";
                            echo "<a href='delete_detailpenjualan.php?id=".$row["id_detail"]."' onclick='return confirm(\"Apakah Anda yakin ingin menghapus data?\")'>Delete</a>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6'>Tidak ada data detail penjualan.</td></tr>";
                    }
                } else {
                    // Display error message if query execution fails
                    echo "<tr><td colspan='6'>Error executing query: " . $koneksi->error . "</td></tr>";
                }

                // Close database connection
                $koneksi->close();
                ?>
            </tbody>
        </table><br>
        <a href="data_detailpenjualan.php"><button type="button">Tampilkan Semua</button></a>
    </div>
    <div class="swiper-pagination position-absolute text-center"></div>
    </section>
    <script src="js/jquery-1.11.0.min.js">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="js/plugins.js"></script>
    <script type="text/javascript" src="js/script.js"></script>
</body>

</html>
<?php
}
?>