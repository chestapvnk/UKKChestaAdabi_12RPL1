<?php

include "koneksi.php";

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    
    if(isset($_GET['id'])) {
        $id_produk = $_GET['id'];

        $sql = "DELETE FROM produk WHERE id_produk = '$id_produk'";

        if ($koneksi->query($sql) === TRUE) {
            header("Location: data_produk.php");
            exit;
        } else {
            echo "Error: " . $sql . "<br>" . $koneksi->error;
        }
    } else {
        echo "id produk tidak ditemukan.";
    }
}


$koneksi->close();
?>
