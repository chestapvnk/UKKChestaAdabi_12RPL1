<?php
$server="localhost";
$username="root";
$password="";
$db="upk_chesta";

$koneksi=new mysqli("$server","$username","$password","$db");
?>