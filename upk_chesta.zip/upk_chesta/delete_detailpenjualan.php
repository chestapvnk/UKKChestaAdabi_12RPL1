<?php
session_start();

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['id_kasir'])) {
    // Jika belum login, arahkan kembali ke halaman login
    header('Location: login.php');
    exit();
}

// Periksa apakah parameter id ada dan merupakan angka
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    // Include file koneksi database
    include "koneksi.php";

    // Escape input untuk mencegah SQL injection
    $id_detail = $koneksi->real_escape_string($_GET['id']);

    // Query untuk menghapus data detail penjualan berdasarkan id
    $sql = "DELETE FROM detail_penjualan WHERE id_detail = $id_detail";

    if ($koneksi->query($sql) === TRUE) {
        // Jika penghapusan berhasil, arahkan kembali ke halaman detail penjualan
        header('Location: data_detailpenjualan.php');
        exit();
    } else {
        // Jika terjadi kesalahan dalam penghapusan data, tampilkan pesan error
        echo "Error: " . $sql . "<br>" . $koneksi->error;
    }

    // Tutup koneksi database
    $koneksi->close();
} else {
    // Jika parameter id tidak ada atau bukan angka, arahkan kembali ke halaman detail penjualan
    header('Location: data_detailpenjualan.php');
    exit();
}
?>
