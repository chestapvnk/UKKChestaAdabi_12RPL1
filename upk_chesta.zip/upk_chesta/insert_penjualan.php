<?php
session_start();
if (!isset($_SESSION["id_kasir"])) {
  header("location: login.php");
  exit(); // Penting untuk menghentikan eksekusi skrip setelah mengarahkan pengguna
} else // Penting untuk menghentikan eksekusi skrip setelah mengarahkan pengguna

  // Konten halaman dashboard di sini
  // ...
  
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Produk</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="author" content="">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <link rel="prekoneksiect" href="https://fonts.googleapis.com">
    <link rel="prekoneksiect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Jost:wght@300;400;500&family=Lato:wght@300;400;700&display=swap"
        rel="stylesheet">
    <style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 0;
        background: linear-gradient(to right, #667db6, #0082c8, #0082c8, #667db6);
        color: #333;
    }

    .container {
    width: 40%;
    margin: 50px auto;
    padding: 20px;
    background-color: #fff;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

    h2 {
        text-align: center;
        color: #000000;
    }

    .form-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-left: 10px;
    }

   
    /* label {
        margin-bottom: 10px;
        font-weight: bold;
    } */

    input[type="text"] {
        padding: 10px;
        width: 100%;
        margin: auto;
        margin-bottom: 20px;
        border: none;
        border-radius: 5px;
        background-color: #f2f2f2;
        box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
    }

    input[type="submit"] {
        padding: 10px 20px;
        background-color: #215e82;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    input[type="submit"]:hover {
        background-color: #215e82;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    table th,
    table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    table th {
        background-color: #f2f2f2;
    }

    table tr:nth-child(even) {
        background-color: #f2f2f2;
    }

    form {
        margin-bottom: 20px;
    }

    button[name="search"] {

        padding: 10px 20px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;

    }

    button[name="search"]:hover {
        background-color: #45a049;
    }

    /* Style untuk tombol "Tampilkan Semua" */
    button[type="button"] {
        padding: 10px 20px;
        background-color: #215e82;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    button[type="button"]:hover {
        background-color: #1a4761;
    }
    .form-actions {
    display: flex;
    justify-content: space-between;
}

.form-actions button {
    flex: 1;
    margin-left: 6px; /* Atur jarak antara tombol */
}
    </style>


    <!-- script
    ================================================== -->
    <script src="js/modernizr.js"></script>
</head>

<body data-bs-spy="scroll" data-bs-target="#navbar" data-bs-root-margin="0px 0px -40%" data-bs-smooth-scroll="true"
    tabindex="0">

    <!-- navbar -->
    <header id="header" class="site-header header-scrolled position-relative text-black bg-light">
        <nav id="header-nav" class="navbar navbar-expand-lg px-3 mb-3">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.html">
                    <img src="images/main-logo.png" class="logo">
                </a>
                <button class="navbar-toggler d-flex d-lg-none order-3 p-2" type="button" data-bs-toggle="offcanvas"
                    data-bs-target="#bdNavbar" aria-controls="bdNavbar" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <svg class="navbar-icon">
                        <use xlink:href="#navbar-icon"></use>
                    </svg>
                </button>
                <div class="offcanvas offcanvas-end" tabindex="-1" id="bdNavbar"
                    aria-labelledby="bdNavbarOffcanvasLabel">
                    <div class="offcanvas-header px-4 pb-0">
                        <a class="navbar-brand" href="index.html">
                            <img src="images/main-logo.png" class="logo">
                        </a>
                        <button type="button" class="btn-close btn-close-black" data-bs-dismiss="offcanvas"
                            aria-label="Close" data-bs-target="#bdNavbar"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul id="navbar"
                            class="navbar-nav text-uppercase justify-content-end align-items-center flex-grow-1 pe-3">
                            <li class="nav-item">
                                <a class="nav-link me-4" href="#billboard">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link me-4" href="#company-services">Kasir</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link me-4 dropdown-toggle link-dark" data-bs-toggle="dropdown" href="#"
                                    role="button" aria-expanded="false">Produk</a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a class="nav-link me-4 ctive " href="data_produk.php">Data Produk</a>
                                    </li>
                                    <li>
                                        <a class="nav-link me-4 ctive " href="tambah_produk.php">Tambah Produk</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link me-4 dropdown-toggle link-dark" data-bs-toggle="dropdown" href="#"
                                    role="button" aria-expanded="false">Penjualan</a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="about.html" class="dropdown-item">Penjualan</a>
                                    </li>
                                    <li>
                                        <a href="blog.html" class="dropdown-item">Detail Penjualan</a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <div class="user-items ps-5">
                                    <ul class="d-flex justify-content-end list-unstyled">

                                        <li class="nav-item active">
                                            <a class="nav-link" href="logout.php">Logout</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <!-- konten -->

    <div class="container">
        <h2>Form Insert Penjualan</h2>
        <form action="" method="POST">
            <label for="id_penjualan">Penjualan ID:</label><br>
            <input type="text" id="id_penjualan" name="id_penjualan" required><br>
            
            <label for="id_detail">Detail ID:</label><br>
            <input type="text" id="id_detail" name="id_detail" required><br>
            
            <table border="1">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Jumlah</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody id="detail_penjualan">
                    <!-- Baris detail penjualan akan ditambahkan secara dinamis menggunakan JavaScript -->
                </tbody>
            </table>
            <button type="button" onclick="tambahBaris()">Tambah Produk</button><br><br><br>
                
            <label for="tgl_penjualan">Tanggal Penjualan:</label><br>
            <input type="date" id="tgl_penjualan" name="tgl_penjualan" required><br><br>
                
            <input type="submit" value="Submit"><br></br>
            <button type="button" onclick="cancel()">Cancel</button>
        </form>
    </div>

    <script>
    // Fungsi untuk mengambil data produk dari server menggunakan AJAX
    function getDataProduk(selectElement) {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "get_produk.php", true); // Sesuaikan dengan nama file PHP yang digunakan untuk mengambil data produk
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4 && xhr.status == 200) {
                var response = xhr.responseText;
                selectElement.innerHTML = response;
            }
        };
        xhr.send();
    }

    function cancel() {
        window.location.href = "data_penjualan.php"; // Ganti dengan halaman tujuan untuk cancel
    }

    function tambahBaris() {
        var table = document.getElementById("detail_penjualan");
        var row = table.insertRow();
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        var cell3 = row.insertCell(2);
        
        // Buat ID unik untuk elemen dropdown ProdukID
        var uniqueID = 'id_produk_' + Math.random().toString(36).substr(2, 9);
        
        cell1.innerHTML = '<select id="' + uniqueID + '" name="id_produk[]" required></select>'; // Kosongkan dulu dropdown
        cell2.innerHTML = '<input type="text" name="jumlah[]" onchange="hitungTotal()">'; // Ubah input menjadi text
        cell3.innerHTML = '<button type="button" onclick="hapusBaris(this)">Hapus</button>';
        
        // Panggil fungsi untuk mengambil data produk setelah menambahkan baris baru
        var selectElement = document.getElementById(uniqueID);
        getDataProduk(selectElement);
    }

    function hapusBaris(button) {
        var row = button.parentNode.parentNode;
        row.parentNode.removeChild(row);
        hitungTotal();
    }
    </script>


</body>
</html>

<?php
// Koneksi ke database
include "koneksi.php";

// Tangkap data dari formulir jika ada
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil nilai dari form
    $id_detail = $_POST['id_detail'];
    $id_penjualan = $_POST['id_penjualan'];
    $tgl_penjualan = $_POST['tgl_penjualan'];
    $JumlahProdukArray = $_POST['jumlah']; // Ubah menjadi array untuk menangkap jumlah produk
    $ProdukIDArray = $_POST['id_produk']; // Ubah menjadi array untuk menangkap ID produk

    // Variabel untuk menyimpan total harga
    $totalHarga = 0;

    // Loop untuk setiap produk yang dibeli
    for ($i = 0; $i < count($ProdukIDArray); $i++) {
        // Ambil nilai dari form
        // Generate ID detail penjualan secara unik
        $id_produk = $ProdukIDArray[$i];
        $jmlh_produk = $JumlahProdukArray[$i];

        // Ambil harga produk dari tabel produk
        $sql_harga_produk = "SELECT harga, stok FROM produk WHERE id_produk = '$id_produk'";
        $result_produk = $koneksi->query($sql_harga_produk);

        if ($result_produk->num_rows > 0) {
            $row_produk = $result_produk->fetch_assoc();
            $harga = $row_produk['harga'];
            $stok = $row_produk['stok'];

            // Cek apakah stok mencukupi
            if ($JumlahProduk <= $stok) {
                // Kurangi stok
                $stokBaru = $stok - $jmlh_produk;
                $sql_update_stok = "UPDATE produk SET stok = '$stokBaru' WHERE id_produk = '$id_produk'";
                if ($koneksi->query($sql_update_stok) !== TRUE) {
                    echo "Error updating stok: " . $koneksi->error;
                }

                // Hitung subtotal
                $SubTotal = $jmlh_produk * $harga;
                $totalHarga += $SubTotal;

                // Query untuk menyimpan data ke dalam tabel detail_penjualan
                $sql_detail_penjualan = "INSERT INTO detail_penjualan (id_detail, id_penjualan, id_produk, jmlh_produk, sub_total) VALUES ('$id_detail', '$id_penjualan', '$id_produk', '$jmlh_produk', '$SubTotal')";

                if ($koneksi->query($sql_detail_penjualan) !== TRUE) {
                    echo "Error inserting detail penjualan: " . $koneksi->error;
                }
            } else {
                echo "Stok produk tidak mencukupi untuk produk dengan ID: " . $ProdukID;
            }
        } else {
            echo "Error fetching produk data: " . $koneksi->error;
        }
    }

    // Query untuk menyimpan data ke dalam tabel penjualan
    $sql_penjualan = "INSERT INTO penjualan (id_penjualan, tgl_penjualan, ttl_harga) VALUES ('$id_penjualan', '$tgl_penjualan', '$totalHarga')";

    if ($koneksi->query($sql_penjualan) === TRUE) {
      echo"<script>window.location='data_penjualan.php';</script>";
       
        exit();
    } else {
        echo "Error inserting penjualan data: " . $koneksi->error;
    }
}

// Tutup koneksi
$koneksi->close();
?>